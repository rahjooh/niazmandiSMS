<?php
 
     function getTopNPosts($count)
  {
      connectToDB();
      return mysql_query("SELECT * FROM massage ORDER BY ID DESC limit 0, $count");
  }
        
   function connectToDB()
  {
     mysql_connect('localhost', 'root', '') ;
     mysql_select_db('sms');
     mysql_query("SET NAMES UTF8");
  }
 
  function insert ($number , $massage  )
  {
      connectToDB();
      $ID10 =   mysql_query("SELECT MAX('ID') FROM massage");
      $Num = mysql_query("SELECT * FROM massage WHERE cell_number = '$number' AND massage = '$massage' AND ID > '$ID10' " );
      if (!(mysql_num_rows($Num)>0 ))
      { 
      $operator = substr ($number , 0 , 4);
      $Class = "other";
      switch ($operator)  {
    case "0910" : $Class = "hamrah"; break ;
    case "0911" : $Class = "hamrah"; break ;
    case "0912" : $Class = "hamrah"; break ;
    case "0913" : $Class = "hamrah"; break ;
    case "0914" : $Class = "hamrah"; break ;
    case "0915" : $Class = "hamrah"; break ;
    case "0916" : $Class = "hamrah"; break ;
    case "0917" : $Class = "hamrah"; break ;
    case "0918" : $Class = "hamrah"; break ;
    case "0919" : $Class = "hamrah"; break ;
    case "0930" : $Class = "irancell";  break ;
    case "0935" : $Class = "irancell";  break ;
    case "0936" : $Class = "irancell";  break ;
    case "0937" : $Class = "irancell";  break ;
    case "0938" : $Class = "irancell";  break ;
    case "0939" : $Class = "irancell";  break ;
    case "0932" : $Class = "talia";    break ;
    case "0921" : $Class = "rightel";  break ;
      }
      

     $query = "INSERT INTO `massage`(`ID`, `cell_number`, `massage`, `status`, `detail`, `Class`, `date`)
                             VALUES ('','$number','$massage','0','','$Class','')" ;
    
    $S = mysql_query($query) ;
    if(! $S)                                   
       echo ' خطا در هنگام بروز کردن دیتابیس : '.mysql_error();

    
      }
  }
?>
