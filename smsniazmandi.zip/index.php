<?php

      include 'funcAdd.php';
      if (isset ($_GET["FROM"]) )
      {
          insert($_GET["FROM"], $_GET["TEXT"])  ;
      }


  echo <<<_END
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" media="all" href="style.css">

<title>Untitled Document</title>
</head>

<body>
<div class="site">
    <div class="menu">
        <ul>
            <li><a href="#">خانه</a></li>
            <li><a href="#">درباره سایت</a></li>
            <li><a href="#">موضوعات</a></li>
            <li style="border: hidden;"><a href="#">تماس با ما</a></li>
        </ul>
    </div>
    <div class="content">
        <table>
_END;
        // /check do we have a starting page?

        

 

connectToDB();

    $topPosts = getTopNPosts(50);
                for($i=0; $i < mysql_num_rows($topPosts); $i++)
                {
                    $cell_number = mysql_result($topPosts, $i, 'cell_number');
                    $massage  = mysql_result($topPosts, $i, 'massage');
                    $Class  = mysql_result($topPosts, $i, 'Class');
                  //  echo "<li><a href='#'>$Class</a></li>";
                             echo  "<tr>
                <td class=$Class>$cell_number</td>
                 <td class='text'>$massage</td>";
                }
                
                
/*for ($i=$result ; $i>0 ; $i--)
{
   $num = "select ce"; 
}
    */


 /* 
$res = mysql_fetch_row($result);

$numRows = $res[0];

$maxItemsOnPage = 15;
$numberOfPages = ceil($numRows / $maxItemsOnPage);


//lets get the data for this page
$query = "SELECT * FROM massage ORDER BY ID DESC LIMIT " . (($page - 1) * $maxItemsOnPage) ."," . $maxItemsOnPage ;
$result = mysql_query($query, $link);


       //      <li><span class=$Class>$Number</span><p>$Matn</p></li>
       
       

//do something  
     $title = mysql_result($result,0, 'title');
                    echo "<li><a href='#'>$title</a></li>";
//show the links

if ($page < $numberOfPages) {

    echo '<a href="' . $_SERVER["PHP_SELF"] . '?page=' . ($page + 1) .

        '">Next page &gt;&gt;</a>';

}

 

if ($page > 1) {

    echo '<a href="' . $_SERVER["PHP_SELF"] . '?page=' . ($page - 1) .

        '">&lt;&lt; Prev page</a>';
}
       */       
              
echo <<<_END
        </table>
    </div>
    <div class="footer">
        <div class="menu_footer">
            <ul>
                <li><a href="#">خانه</a></li>
                <li><a href="#">درباره سایت</a></li>
                <li><a href="#">موضوعات</a></li>
                <li><a href="#">راهنمای استفاده از سایت</a></li>
                <li><a href="#">تبلیغات بنری</a></li>
                <li><a href="#">سوالات متداول</a></li>
                <li><a class="noborder" href="#">تماس با ما</a></li>
            </ul>
        <p>تمامی حقوق این سایت برای هادی و محمد محفوظ میباشد و هرگونه کپی برداری طبق قانون کپی رایت 2013 ممنوع بوده.</p>
        <p>کسب و کارتان را رایگان تبلیغ کنید.</p>
        </div>
    </div>
</div>
</body>
</html>
_END;

?>
